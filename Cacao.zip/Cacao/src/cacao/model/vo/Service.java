package cacao.model.vo;

public class Service {

	private int sId;
	private String sKind;
	private String sCate;
	private String sDate;
	private String sTitle;
	private String sDetail;
	private String sImage;
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public String getsKind() {
		return sKind;
	}
	public void setsKind(String sKind) {
		this.sKind = sKind;
	}
	public String getsCate() {
		return sCate;
	}
	public void setsCate(String sCate) {
		this.sCate = sCate;
	}
	public String getsDate() {
		return sDate;
	}
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	public String getsTitle() {
		return sTitle;
	}
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}
	public String getsDetail() {
		return sDetail;
	}
	public void setsDetail(String sDetail) {
		this.sDetail = sDetail;
	}
	public String getsImage() {
		return sImage;
	}
	public void setsImage(String sImage) {
		this.sImage = sImage;
	}
	
}
