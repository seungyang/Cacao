package cacao.model.vo;

public class Order {

	private String oId;
	private String dId;
	private String mEmail;
	private String iId;
	private String oCnt;
}
