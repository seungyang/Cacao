package cacao.model.vo;

public class Info {

	private int iId;
	private String iChar;
	private String iCate;
	private String iName;
	private String iCost;
	private String iCnt;
	private String iColor;
	private String iKor;
	private String iImg;
	private String iImgcnt;
	private String iDetail;
	
	public int getiId() {
		return iId;
	}
	public void setiId(int iId) {
		this.iId = iId;
	}
	public String getiChar() {
		return iChar;
	}
	public void setiChar(String iChar) {
		this.iChar = iChar;
	}
	public String getiCate() {
		return iCate;
	}
	public void setiCate(String iCate) {
		this.iCate = iCate;
	}
	public String getiName() {
		return iName;
	}
	public void setiName(String iName) {
		this.iName = iName;
	}
	public String getiCost() {
		return iCost;
	}
	public void setiCost(String iCost) {
		this.iCost = iCost;
	}
	public String getiCnt() {
		return iCnt;
	}
	public void setiCnt(String iCnt) {
		this.iCnt = iCnt;
	}
	public String getiColor() {
		return iColor;
	}
	public void setiColor(String iColor) {
		this.iColor = iColor;
	}
	public String getiKor() {
		return iKor;
	}
	public void setiKor(String iKor) {
		this.iKor = iKor;
	}
	public String getiImg() {
		return iImg;
	}
	public void setiImg(String iImg) {
		this.iImg = iImg;
	}
	public String getiImgcnt() {
		return iImgcnt;
	}
	public void setiImgcnt(String iImgcnt) {
		this.iImgcnt = iImgcnt;
	}
	public String getiDetail() {
		return iDetail;
	}
	public void setiDetail(String iDetail) {
		this.iDetail = iDetail;
	}
	
	

}
