package cacao.model.vo;

public class Deliver {
	private int dId;
	private String dPay;
	private String dName;
	private String dAddr;
	private String dNote;
	private String dStatus;
}
