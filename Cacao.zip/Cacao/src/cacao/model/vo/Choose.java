package cacao.model.vo;

public class Choose {
	private int cId;
	private String mEmail;
	private int iId;
}
