package cacao.model.vo;

public class Member {

	private String mEmail;
	private String mName;
	private String mCheck;
	private String mPwd;
	private String mBirth;
	private String mSex;
	
	
}
